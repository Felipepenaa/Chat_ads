package com.example.ads_chat1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
